package usedcar.shopping;

public interface membertype {

	public String getUser_id(); 
	
	public String getTel(); 
	
	
}
