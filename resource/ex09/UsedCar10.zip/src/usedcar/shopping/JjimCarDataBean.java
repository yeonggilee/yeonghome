package usedcar.shopping;

public class JjimCarDataBean { //이영기
	private int jjim_idx;
	private String user_id;
	private int car_idx;
	private String car_img1;
	private String title;
	private String car_brand;
	private String car_model;
	private String car_oilType;
	private String car_birth;
	private String car_mileage;
	private String car_price;
	private String car_location;
	
	public int getJjim_idx() {
		return jjim_idx;
	}
	public void setJjim_idx(int jjim_idx) {
		this.jjim_idx = jjim_idx;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public int getCar_idx() {
		return car_idx;
	}
	public void setCar_idx(int car_idx) {
		this.car_idx = car_idx;
	}
	public String getCar_img1() {
		return car_img1;
	}
	public void setCar_img1(String car_img1) {
		this.car_img1 = car_img1;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getCar_brand() {
		return car_brand;
	}
	public void setCar_brand(String car_brand) {
		this.car_brand = car_brand;
	}
	public String getCar_model() {
		return car_model;
	}
	public void setCar_model(String car_model) {
		this.car_model = car_model;
	}
	public String getCar_oilType() {
		return car_oilType;
	}
	public void setCar_oilType(String car_oilType) {
		this.car_oilType = car_oilType;
	}
	public String getCar_birth() {
		return car_birth;
	}
	public void setCar_birth(String car_birth) {
		this.car_birth = car_birth;
	}
	public String getCar_mileage() {
		return car_mileage;
	}
	public void setCar_mileage(String car_mileage) {
		this.car_mileage = car_mileage;
	}
	public String getCar_price() {
		return car_price;
	}
	public void setCar_price(String car_price) {
		this.car_price = car_price;
	}
	public String getCar_location() {
		return car_location;
	}
	public void setCar_location(String car_location) {
		this.car_location = car_location;
	}

	
}
