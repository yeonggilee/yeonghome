package usedcar.shopping;

public class JjimListDataBean { //이영기
	private int jjim_idx;
	private String user_id;
	private int car_idx;
	
	public int getJjim_idx() {
		return jjim_idx;
	}
	public void setJjim_idx(int jjim_idx) {
		this.jjim_idx = jjim_idx;
	}
	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public int getCar_idx() {
		return car_idx;
	}
	public void setCar_idx(int car_idx) {
		this.car_idx = car_idx;
	}
	
	
}

