package org.comstudy21.member.view;

import org.comstudy21.member.model.DTO;

public interface InputDialog {

	public DTO getInput();
	public void resetInput();
}
