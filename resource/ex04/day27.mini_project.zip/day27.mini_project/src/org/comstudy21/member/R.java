package org.comstudy21.member;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.FlowLayout;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;

import org.comstudy21.member.jdbc.JdbcUtil;
import org.comstudy21.member.model.DAO;
import org.comstudy21.member.model.DTO;
import org.comstudy21.member.view.AgeChart;
import org.comstudy21.member.view.ChartModalDialog;
import org.comstudy21.member.view.DocumentationModalDialog;
import org.comstudy21.member.view.ExcelWriter;
import org.comstudy21.member.view.GenderChart;
import org.comstudy21.member.view.InsertModalDialog;
import org.comstudy21.member.view.SelectModalDialog;
import org.jfree.chart.ChartPanel;

public class R {//��� public������ �� ���Ϻ� ���������� ����
	
	//ManagementProgram.java--------------------------------------------
	public static DAO dao = new DAO();
	public static ExcelWriter ew = new ExcelWriter();
	
	public static JPanel paneOfContent;
	public static SelectModalDialog dlOfSelect;
	public static InsertModalDialog dlOfInsert;
	public static ChartModalDialog dlOfChart;
	public static DocumentationModalDialog dlOfDoc;
	
	public static JTable table;

	public static DTO dto;
	public static DTO dto2;
	public static DTO[] dtoArr;

	public static CardLayout cardLayout;
	public static JPanel paneOfLogin = new JPanel(null);
	public static JPanel paneOfMain = new JPanel(new BorderLayout());
	public static JPanel paneOfBtns = new JPanel(new BorderLayout());
	public static JPanel paneOfMainBtns = new JPanel();
	public static JPanel paneOfSubBtns = new JPanel();
	public static JPanel paneOfTable = new JPanel(new BorderLayout());
	public static JPanel paneOfInfo = new JPanel(new BorderLayout());
	public static JPanel paneOfText = new JPanel(new FlowLayout(2, 10, 10));
	public static JPanel paneOfImg = new JPanel(new FlowLayout(1, 0, 30));
	public static JPanel paneOfMemo = new JPanel(new FlowLayout(1, 0, 10));
	
	public static JButton selectAllBtn = new JButton("��ü");
	public static JButton selectBtn = new JButton("�˻�");
	public static JButton insertBtn = new JButton("�߰�");
	public static JButton updateBtn = new JButton("����");
	public static JButton deleteBtn = new JButton("����");
	
	public static JButton chartBtn = new JButton("��Ʈ");
	public static JButton docBtn = new JButton("���� ���̺� ����ȭ");

	//SelectModalDialog.java--------------------------------------------
	
	public static boolean okSelect;
	public static JLabel lb = new JLabel("�˻��� �̸� �Է�");
	public static JTextField tf = new JTextField(10);
	public static JButton okBtn = new JButton("Ȯ��");
	
	//InsertModalDialog.java--------------------------------------------

	public static boolean okInsert;
	
	public static DTO[] otherArr;
	
	public static String name = null;
	public static String birth = null;
	public static String phone = null;
	public static String email = null;
	public static String gender = null;
	public static String image = null;
	public static String memo = null;

	public static JLabel lbOfName = new JLabel("����(�ʼ�)");
	public static JLabel lbOfBirth = new JLabel("�������");
	public static JLabel lbOfPhone = new JLabel("��ȭ��ȣ(�ʼ�)");
	public static JLabel lbOfEmail = new JLabel("�̸���");
	public static JLabel lbOfAt = new JLabel("@");
	public static JLabel lbOfGender = new JLabel("����");
	public static JLabel lbOfImage = new JLabel("�̹���");
	public static JLabel lbOfMemo = new JLabel("�޸�");

	public static JTextField tfOfName = new JTextField(10);
	public static JTextField tfOfPhone1 = new JTextField(4);
	public static JTextField tfOfPhone2 = new JTextField(4);
	public static JTextField tfOfEmail1 = new JTextField(10);
	public static JTextField tfOfEmail2 = new JTextField(10);
	public static JTextField tfOfFile = new JTextField(10);

	public static JTextArea ta = new JTextArea();
	public static JScrollPane sp = new JScrollPane(ta);

	public static Vector<String> listOfyear = new Vector<>();
	public static Vector<String> listOfMonth = new Vector<>();
	public static Vector<String> listOfDate = new Vector<>();
	
	private static String[] phoneAddr = {
			"010", "02", "051", "053", "032", "062", 
			"042", "052", "044", "031", "033", "043", 
			"041", "063", "061", "054", "055", "064"
			};
	private static String[] emailAddr = {
			"",
			"naver.com", 
			"hanmail.net", 
			"gmail.com", 
			"nate.com", 
			"outlook.kr"
			};
	
	public static JComboBox<String> cbOfYear = null;
	public static JComboBox<String> cbOfMonth = null;
	public static JComboBox<String> cbOfDate = null;
	public static JComboBox<String> cbOfPhone = new JComboBox<>(phoneAddr);
	public static JComboBox<String> cbOfEmail = new JComboBox<>(emailAddr);

	public static JRadioButton rbOfMan = new JRadioButton("��", true);
	public static JRadioButton rbOfWoman = new JRadioButton("��", false);
	public static ButtonGroup bg = new ButtonGroup();

	public static JFileChooser fc = new JFileChooser();
	public static FileNameExtensionFilter filter = new FileNameExtensionFilter("JPG & PNG", "jpg", "png");

	public static JButton findBtn = new JButton("�̹��� ã��");
	public static JButton okBtn2 = new JButton("Ȯ��");
	
	//ManagementProgram.java--------------------------------------------
	
	public static JTextField tfOfName2 = new JTextField(12);
	public static JTextField tfOfBirth = new JTextField(12);
	public static JTextField tfOfPhone = new JTextField(12);
	public static JTextField tfOfEmail = new JTextField(12);
	public static JTextField tfOfGender = new JTextField(12);

	public static JTextArea taOfMemo = new JTextArea();
	public static JScrollPane scrollPane = new JScrollPane(taOfMemo);

	public static JLabel imgLb = new JLabel();

	public static JLabel lbOfMainTitle = new JLabel("���� ���� �ý���");
	public static JLabel lbOfSubTitleLb = new JLabel("~.~.~.~.~.~.~.~ ���Ⱑ ���� ~.~.~.~.~.~.~.~");
	public static JLabel lbOfId = new JLabel("����ڸ�");
	public static JLabel lbOfPw = new JLabel("��й�ȣ");

	public static JTextField tfOfId = new JTextField();
	public static JPasswordField tfOfPw = new JPasswordField();
	
	public static JButton okBtn4 = new JButton("Ȯ��");
	public static JButton changeUser = new JButton("����� ����");

	//ChartModalDialog.java--------------------------------------------

	public static JTabbedPane paneOfTabs = new JTabbedPane();
	public static ChartPanel paneOfAgeChart = new ChartPanel(null);
	public static ChartPanel paneOfGenChart = new ChartPanel(null);

	public static AgeChart ageChart = new AgeChart();
	public static GenderChart genChart = new GenderChart();

	//DocumentationModalDialog.java--------------------------------------------

	public static boolean okDoc;
	
	public static JLabel lbOfFileName = new JLabel("���� �̸�");
	public static JLabel lbOfLocation = new JLabel("���� ��ġ");

	public static JTextField tfOfFileName = new JTextField(26);
	public static JTextField tfOfLocation = new JTextField(20);

	public static JButton chooseBtn = new JButton("����");
	public static JButton okBtn3 = new JButton("����");

	public static JFileChooser fc2 = new JFileChooser();
	
	static{
		
		//InsertModalDialog.java-----------------------------------------
		
		listOfyear.add("");
		listOfMonth.add("");
		listOfDate.add("");
		
		for(int i = 2019; i > 1939; i--){
			listOfyear.add(i + "");
		}
		for(int i = 1; i < 13; i++){
			listOfMonth.add(i + "");
		}
		for(int i = 1; i < 32; i++){
			listOfDate.add(i + "");
		}
		cbOfYear = new JComboBox<>(listOfyear);
		cbOfMonth = new JComboBox<>(listOfMonth);
		cbOfDate = new JComboBox<>(listOfDate);

		tfOfName.setDocument(new JTextFieldLimit(20));
		tfOfEmail1.setDocument(new JTextFieldLimit(14));
		tfOfEmail2.setDocument(new JTextFieldLimit(15));
		tfOfFile.setDocument(new JTextFieldLimit(100));
		ta.setDocument(new JTextFieldLimit(100));

		tfOfPhone1.setDocument(new JTextFieldOnlyNum(4));
		tfOfPhone2.setDocument(new JTextFieldOnlyNum(4));
		
		tfOfFile.setEditable(false);
		
		fc.setFileFilter(filter);
		
		//ManagementProgram.java-----------------------------------------
		//���̺� ������ �ѹ���..
		table = new JTable();
		table.setAutoCreateRowSorter(true);//���̺� ���� ��� �߰�
		table.getTableHeader().setReorderingAllowed(false); //�÷� �̵� �Ұ�
		//table.getTableHeader().setResizingAllowed(false); //�÷� ũ�� ���� �Ұ�
				
		tfOfName2.setEditable(false);
		tfOfBirth.setEditable(false);
		tfOfPhone.setEditable(false);
		tfOfEmail.setEditable(false);
		tfOfGender.setEditable(false);
		taOfMemo.setEditable(false);
		
		//DocumentationModalDialog.java--------------------------------------------
		
		tfOfLocation.setEditable(false);
		tfOfLocation.setText(System.getProperty("user.home")+"\\Documents");
	}
	
}
