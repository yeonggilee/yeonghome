package org.comstudy21.member.view;

import static org.comstudy21.member.R.*;

import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.StringTokenizer;
import java.util.Vector;

import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.plaf.basic.BasicBorders.RadioButtonBorder;

import org.comstudy21.member.model.DTO;

public class InsertModalDialog extends JDialog implements InputDialog{
	
	public InsertModalDialog(JFrame frame, String title) {
		super(frame, title, true);//true - ��� ���̾�α׷� ����
		init();
		set();
		start();
	}
	
	private void init() {
		setSize(480, 640);
		Dimension sc = Toolkit.getDefaultToolkit().getScreenSize();//â ũ�� ���ؼ�
		//������ ��ġ ����
		setLocation((int)(sc.getWidth()/2 - getWidth()/2), (int)(sc.getHeight()/2 - getHeight()/2));
		setResizable(false);//â ����
	}
	
	private void set() {
		setLayout(null);

		lbOfName.setBounds(10, 20, 100, 20);
		lbOfBirth.setBounds(10, 70, 100, 20);
		lbOfPhone.setBounds(10, 120, 100, 20);
		lbOfEmail.setBounds(10, 170, 100, 20);
		lbOfAt.setBounds(225, 170, 20, 20);
		lbOfGender.setBounds(10, 220, 100, 20);
		lbOfImage.setBounds(10, 270, 100, 20);
		lbOfMemo.setBounds(10, 320, 100, 20);

		add(lbOfName);
		add(lbOfBirth);
		add(lbOfPhone);
		add(lbOfEmail);
		add(lbOfAt);
		add(lbOfGender);
		add(lbOfImage);
		add(lbOfMemo);

		cbOfYear.setBounds(120, 70, 70, 20);
		cbOfMonth.setBounds(200, 70, 50, 20);
		cbOfDate.setBounds(260, 70, 50, 20);
		cbOfPhone.setBounds(120, 120, 60, 20);
		cbOfEmail.setBounds(350, 170, 100, 20);

		add(cbOfYear);
		add(cbOfMonth);
		add(cbOfDate);
		add(cbOfPhone);
		add(cbOfEmail);

		tfOfName.setBounds(120, 20, 170, 20);
		tfOfPhone1.setBounds(190, 120, 60, 20);
		tfOfPhone2.setBounds(260, 120, 60, 20);
		tfOfEmail1.setBounds(120, 170, 100, 20);
		tfOfEmail2.setBounds(245, 170, 100, 20);
		tfOfFile.setBounds(120, 270, 200, 20);
		
		add(tfOfName);
		add(tfOfPhone1);
		add(tfOfPhone2);
		add(tfOfEmail1);
		add(tfOfEmail2);
		add(tfOfFile);
		
		rbOfMan.setBounds(120, 220, 50, 20);
		rbOfWoman.setBounds(170, 220, 50, 20);

		add(rbOfMan);
		add(rbOfWoman);
		
		//������ư �׷�ȭ
		bg.add(rbOfMan);
		bg.add(rbOfWoman);

		findBtn.setBounds(330, 270, 120, 20);
		okBtn2.setBounds(400, 560, 60, 30);
		
		add(findBtn);
		add(okBtn2);
		
		sp.setBounds(120, 320, 300, 200);
		add(sp);	
	}
	
	private void start() {
		
		okBtn2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {

				if(tfOfName.getText().length() == 0 
						|| tfOfPhone1.getText().length() == 0
						|| tfOfPhone2.getText().length() == 0){
					JOptionPane.showMessageDialog(null, "�ʼ��Է� ������ �����մϴ�", "���", JOptionPane.WARNING_MESSAGE);
					return;
				}
				
				name = tfOfName.getText();
				birth = cbOfYear.getSelectedItem() + "-" + cbOfMonth.getSelectedItem() + "-" + cbOfDate.getSelectedItem();
				phone = cbOfPhone.getSelectedItem() + "-" + tfOfPhone1.getText() + "-" + tfOfPhone2.getText();
				email = tfOfEmail1.getText() + lbOfAt.getText() + tfOfEmail2.getText();
				if(rbOfMan.isSelected()){
					gender = rbOfMan.getText();
				}
				else {
					gender = rbOfWoman.getText();
				}
				image = tfOfFile.getText();
				memo = ta.getText();
				
				if(otherArr != null){
					for(DTO d : otherArr){
						if(d.getPhone().equals(phone)){//�ٸ� ����� ��ȭ��ȣ�� ������
							JOptionPane.showMessageDialog(null, "��ȭ��ȣ�� �ߺ��Ǿ����ϴ�.", "���", JOptionPane.ERROR_MESSAGE);
							return;
						}
					}
				}
				
				okInsert = true;
				setVisible(false);
			}
		});
		
		findBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
	            fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
	            
				int ret = fc.showOpenDialog(null);
				if(ret != JFileChooser.APPROVE_OPTION){
					JOptionPane.showMessageDialog(null, "������ �������� �ʾҽ��ϴ�", "���", JOptionPane.WARNING_MESSAGE);
					return;
				}
				
				tfOfFile.setText(fc.getSelectedFile().getPath());
			}
		});
		
		cbOfEmail.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				JComboBox<String> cb = (JComboBox<String>) e.getSource();
				int index = cb.getSelectedIndex();
				tfOfEmail2.setText(cb.getItemAt(index));
			}
		});
	}

	@Override
	public DTO getInput() {
		if(okInsert == false){
			resetInput();
			return null;
		}
		else {
			return new DTO(name, birth, phone, email, gender, image, memo);
		}
	}

	@Override
	public void resetInput() {
		
		okInsert = false;
		
		name = "";
		birth = "";
		phone = "";
		email = "";
		gender = "";
		image = "";
		memo = "";
		
		tfOfName.setText("");
		tfOfPhone1.setText("");
		tfOfPhone2.setText("");
		tfOfEmail1.setText("");
		tfOfEmail2.setText("");
		tfOfFile.setText("");
		
		ta.setText("");
		
		cbOfYear.setSelectedIndex(0);
		cbOfMonth.setSelectedIndex(0);
		cbOfDate.setSelectedIndex(0);
		cbOfPhone.setSelectedIndex(0);
		cbOfEmail.setSelectedIndex(0);

		rbOfMan.setSelected(true);
	}
	
	public void setData(DTO[] arr){
		otherArr = arr;
	}
	
	public void setData(DTO d){
		if(d != null){

			String[] spOfBirth = d.getBirth().split("-", 3);
			String[] spOfPhone = d.getPhone().split("-", 3);
			String[] spOfEmail = d.getEmail().split("@", 2);
			
			cbOfYear.setSelectedItem(spOfBirth[0]);
			cbOfMonth.setSelectedItem(spOfBirth[1]);
			cbOfDate.setSelectedItem(spOfBirth[2]);

			cbOfPhone.setSelectedItem(spOfPhone[0]);
			tfOfPhone1.setText(spOfPhone[1]);
			tfOfPhone2.setText(spOfPhone[2]);
			
			tfOfEmail1.setText(spOfEmail[0]);
			tfOfEmail2.setText(spOfEmail[1]);
			cbOfEmail.setSelectedItem(tfOfEmail2.getText());

			tfOfName.setText(d.getName());
			tfOfFile.setText(d.getImage());
			ta.setText(d.getMemo());

			if(d.getGender().equals(rbOfMan.getText())){
				rbOfMan.setSelected(true);
			}
			else{
				rbOfWoman.setSelected(true);
			}
		}
	}
}
