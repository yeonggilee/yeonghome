package org.comstudy21.member.view;

import java.awt.Dimension;
import java.awt.Toolkit;

import javax.swing.JDialog;
import javax.swing.JFrame;

import org.comstudy21.member.model.DTO;

import static org.comstudy21.member.R.*;

public class ChartModalDialog extends JDialog {
	
	public ChartModalDialog(JFrame frame, String title) {
		super(frame, title, true);//true - ��� ���̾�α׷� ����
		init();
		set();
	}
	
	private void init() {
		setSize(800, 480);
		Dimension sc = Toolkit.getDefaultToolkit().getScreenSize();//â ũ�� ���ؼ�
		//������ ��ġ ����
		setLocation((int)(sc.getWidth()/2 - getWidth()/2), (int)(sc.getHeight()/2 - getHeight()/2));
		setResizable(false);//â ����
			
	}
	
	private void set() {
		add(paneOfTabs);

		paneOfTabs.addTab("���̴�", paneOfAgeChart);
		paneOfTabs.addTab("����", paneOfGenChart);
	}
	
	public void setData(DTO[] arr){
		paneOfAgeChart.setChart(ageChart.getChart(arr));
		paneOfGenChart.setChart(genChart.getChart(arr));
	}
}
