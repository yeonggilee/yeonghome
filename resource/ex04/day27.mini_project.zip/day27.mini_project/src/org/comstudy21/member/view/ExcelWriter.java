package org.comstudy21.member.view;

import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.comstudy21.member.model.DTO;

public class ExcelWriter {
	
	public void write(String fileName, String filePath, DTO[] arr) throws IOException{
		HSSFWorkbook workbook = new HSSFWorkbook();
		HSSFSheet sheet = workbook.createSheet("��������");
		HSSFRow row = null;
		HSSFCell cell = null;
		String[] columnNames = {"����", "�������", "��ȭ��ȣ", "�̸���"};
		String[][] data = new String[arr.length][columnNames.length];

		for(int i = 0; i <= arr.length; i++){
			row = sheet.createRow(i);
			if(i < arr.length){
				data[i][0] = arr[i].getName();
				data[i][1] = arr[i].getBirth();
				data[i][2] = arr[i].getPhone();
				data[i][3] = arr[i].getEmail();
			}
			
			for(int j = 0; j < columnNames.length; j++){
				cell = row.createCell(j);
				if(i == 0){
					cell.setCellValue(columnNames[j]);
				}
				else{
					cell.setCellValue(data[i-1][j]);
				}
			}
		}
		
		FileOutputStream fos = new FileOutputStream(filePath + "\\" + fileName + ".xls");
		workbook.write(fos);
		fos.close();
	}
}
