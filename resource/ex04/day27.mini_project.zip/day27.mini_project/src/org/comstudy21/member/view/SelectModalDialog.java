package org.comstudy21.member.view;

import static org.comstudy21.member.R.*;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import org.comstudy21.member.model.DTO;

public class SelectModalDialog extends JDialog implements InputDialog{
	
	public SelectModalDialog(JFrame frame, String title) {
		super(frame, title, true);//true - ��� ���̾�α׷� ����
		init();
		set();
		start();
	}
	
	private void init() {
		setSize(200, 100);
		Dimension sc = Toolkit.getDefaultToolkit().getScreenSize();//â ũ�� ���ؼ�
		//������ ��ġ ����
		setLocation((int)(sc.getWidth()/2 - getWidth()/2), (int)(sc.getHeight()/2 - getHeight()/2));
		setResizable(false);//â����
	}
	
	private void set() {
		setLayout(new FlowLayout());
		
		add(lb);
		add(tf);
		add(okBtn);
	}
	
	private void start() {

		okBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				okSelect = true;
				setVisible(false);
			}
		});
	}
	
	@Override
	public DTO getInput() {
		if(tf.getText().length() == 0 || okSelect == false) {
			resetInput();
			return null;
		}
		else {
			return new DTO(tf.getText(), "", "", "", "", "", "");
		}
	}

	@Override
	public void resetInput() {
		okSelect = false;
		tf.setText("");
	}
}
