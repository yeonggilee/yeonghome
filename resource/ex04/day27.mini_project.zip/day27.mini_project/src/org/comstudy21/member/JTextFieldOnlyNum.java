package org.comstudy21.member;


import javax.swing.JOptionPane;
import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.PlainDocument;

class JTextFieldOnlyNum extends PlainDocument {
	private int limit;

	JTextFieldOnlyNum(int limit) {
		super();
		this.limit = limit;
	}

	JTextFieldOnlyNum(int limit, boolean upper) {
		super();
		this.limit = limit;
	}

	public void insertString(int offset, String str, AttributeSet attr) throws BadLocationException {
		if (str == null)
			return;
		//�ѱ� ���� ó��
		//System.out.println(offset);
		//System.out.println(str);
		//System.out.println(attr);
		//
		String newValue;
		int length = getLength();
		if (length == 0) {
			newValue = str;
		} else {
			String currentContent = getText(0, length);
			StringBuffer currentBuffer = new StringBuffer(currentContent);
			currentBuffer.insert(offset, str);
			newValue = currentBuffer.toString();
		}

		try {
			Integer.parseInt(newValue);
			if ((getLength() + str.length()) <= limit) {
				super.insertString(offset, str, attr);
			}
		} catch (NumberFormatException exception) {			
			//System.out.println((int)str.charAt(0));
			if((int)str.charAt(0) >= 12593 && (int)str.charAt(0) <= 12643){//�ѱ�(����,����)�Է½�
				if(attr == null){//���۰� ������
					return;
				}
				else{//���۰� ������
					super.insertString(offset, " ", null);
				}
			}
			JOptionPane.showMessageDialog(null, "���ڸ� �Է��ϼ���");
		}

	}
}