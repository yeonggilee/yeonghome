package org.comstudy21.member.view;

import static org.comstudy21.member.R.*;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.comstudy21.member.model.DTO;

public class DocumentationModalDialog extends JDialog implements InputDialog{
	
	public DocumentationModalDialog(JFrame frame, String title) {
		super(frame, title, true);//true - ��� ���̾�α׷� ����
		init();
		set();
		start();
	}
	
	private void init() {
		setSize(400, 150);
		Dimension sc = Toolkit.getDefaultToolkit().getScreenSize();//â ũ�� ���ؼ�
		//������ ��ġ ����
		setLocation((int)(sc.getWidth()/2 - getWidth()/2), (int)(sc.getHeight()/2 - getHeight()/2));
		setResizable(false);//â����
	}
	
	private void set() {
		setLayout(new FlowLayout());
		
		add(lbOfFileName);
		add(tfOfFileName);
		add(lbOfLocation);
		add(tfOfLocation);
		add(chooseBtn);
		add(okBtn3);
	}
	
	private void start() {

		chooseBtn.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				fc2.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
	            
	            int ret = fc2.showOpenDialog(null);
				if(ret != JFileChooser.APPROVE_OPTION){
					return;
				}
				
	            tfOfLocation.setText(fc2.getSelectedFile().getPath());
			}
		});
		
		okBtn3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				if(tfOfFileName.getText().length() == 0){
					JOptionPane.showMessageDialog(null, "���� �̸��� �Է����ּ���.", "���", JOptionPane.WARNING_MESSAGE);
					return;
				}
				okDoc = true;
				setVisible(false);
			}
		});
	}
	
	public DTO getInput(){
		if(okDoc == false){
			resetInput();
			return null;
		}
		else {
			return new DTO(tfOfFileName.getText(), "", "", "", "", tfOfLocation.getText(), "");
		}
	}
	
	public void resetInput(){
		okDoc = false;
		tfOfFileName.setText("");
	}

}
