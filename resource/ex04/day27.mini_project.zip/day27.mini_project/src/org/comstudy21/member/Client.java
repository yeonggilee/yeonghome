package org.comstudy21.member;


import org.comstudy21.member.view.ManagementProgram;

public class Client {
	
	public static void main(String[] args) {
		new ManagementProgram().setVisible(true);
	}
}
