package org.comstudy21.member.view;

import java.awt.Color;
import java.text.DecimalFormat;

import org.comstudy21.member.model.DTO;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.PieSectionLabelGenerator;
import org.jfree.chart.labels.StandardPieSectionLabelGenerator;
import org.jfree.chart.plot.PiePlot;
import org.jfree.data.general.DefaultPieDataset;

import static org.comstudy21.member.R.*;

public class GenderChart {

	public JFreeChart getChart(DTO[] arr) {

		DefaultPieDataset dataset = new DefaultPieDataset();
		
		int man = 0, woman = 0;
		if(arr != null){
			for(int i = 0; i < arr.length; i++){
				if(arr[i].getGender().equals("��")){
					man++;
				}
				else{
					woman++;
				}
			}
		}

		dataset.setValue("man", man);
		dataset.setValue("woman", woman);

		//final JFreeChart chart = new JFreeChart(plot);
		final JFreeChart chart = ChartFactory.createPieChart(null, dataset, true, false, false);
		
		PiePlot plot = (PiePlot)chart.getPlot();
        plot.setSectionPaint("man", new Color(232,168,255));
		plot.setSectionPaint("woman", new Color(0,162,255));
        plot.setExplodePercent("man", 0.10);
        plot.setSimpleLabels(true);

        PieSectionLabelGenerator gen = new StandardPieSectionLabelGenerator(
            "{0}: {1} ({2})", new DecimalFormat("0"), new DecimalFormat("0%"));
        plot.setLabelGenerator(gen);
        
		return chart;
	}
}
