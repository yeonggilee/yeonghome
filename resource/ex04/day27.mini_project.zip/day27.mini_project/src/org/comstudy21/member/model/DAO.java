package org.comstudy21.member.model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.comstudy21.member.R;
import org.comstudy21.member.jdbc.JdbcUtil;

public class DAO {
	Connection conn;
	Statement stmt = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;

	final String SELECTTABLE = "SELECT count(*) FROM TAB WHERE TNAME='MEMBER'";
	final String CREATETABLE = "CREATE TABLE MEMBER("
			+ "NAME VARCHAR2(50) NOT NULL, "
			+ "BIRTH VARCHAR2(20), "
			+ "PHONE VARCHAR2(15) NOT NULL PRIMARY KEY, "
			+ "EMAIL VARCHAR2(30), "
			+ "GENDER VARCHAR2(5) CHECK(GENDER IN('��','��')),"
			+ "IMAGE VARCHAR2(100), "
			+ "MEMO VARCHAR2(200)"
			+ ")";
	final String SELECTCOLUMNS = "select cname from col where tname='MEMBER'";
	final String INSERT = "insert into member values (?,?,?,?,?,?,?)";
	final String SELECTALL = "select * from member";
	final String SELECTALLEXCLUDEONE = "select * from member where phone <> ?";
	final String SELECT = "select * from member where name like ?";
	final String SELECTONE = "select * from member where phone = ?";
	final String UPDATE = "update member set " 
			+ "name = ?, " 
			+ "birth = ?, " 
			+ "phone = ?, " 
			+ "email = ?, "
			+ "gender = ?, " 
			+ "image = ?, " 
			+ "memo = ? " 
			+ "where phone = ?";
	final String DELETE = "delete from member where phone = ?";

	public DAO() {
		// TODO Auto-generated constructor stub
	}

	public DAO(Connection conn) {
		this.conn = conn;
	}

	public void setConn(Connection conn) {
		if(this.conn != null){
			JdbcUtil.close(this.conn);
		}
		this.conn = conn;
	}
	
	public int checkConnection(){
		if(conn != null){
			return 1;
		}
		else{
			return 0;
		}
	}

	public int checkTable() {
		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(SELECTTABLE);
			if (rs.next()) {
				int cnt = rs.getInt(1);
				if (cnt == 0) {
					stmt.executeUpdate(CREATETABLE);
					System.out.println("���̺��� ���� �Ǿ����ϴ�.");
				} else {
					System.out.println("���̺��� �̹� ���� �մϴ�!");
					
					rs = stmt.executeQuery(SELECTCOLUMNS);
					String cname = "";
					while (rs.next()){
						cname = cname + rs.getString(1) + " ";
					}
					if(!cname.trim().equals("NAME BIRTH PHONE EMAIL GENDER IMAGE MEMO")){
						return 0;
					}
				}
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(stmt);
		}
		return 1;
	}

	// ó��
	public DTO[] selectAll() {

		DTO[] dtoArr = null;
		ArrayList<DTO> dtoList = new ArrayList<>();

		try {
			stmt = conn.createStatement();
			rs = stmt.executeQuery(SELECTALL);

			while (rs.next()) {
				DTO dto = new DTO();
				dto.setName(rs.getString(1));
				dto.setBirth(rs.getString(2));
				dto.setPhone(rs.getString(3));
				dto.setEmail(rs.getString(4));
				dto.setGender(rs.getString(5));
				dto.setImage(rs.getString(6));
				dto.setMemo(rs.getString(7));

				dtoList.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(stmt);
		}

		if (dtoList.size() != 0) {
			dtoArr = new DTO[dtoList.size()];
			dtoList.toArray(dtoArr);
		}
		return dtoArr;
	}

	public DTO[] select(DTO d) {

		DTO[] dtoArr = null;
		ArrayList<DTO> dtoList = new ArrayList<>();

		try {
			pstmt = conn.prepareStatement(SELECT);
			pstmt.setString(1, "%" + d.getName() + "%");
			rs = pstmt.executeQuery();

			while (rs.next()) {
				DTO dto = new DTO();
				dto.setName(rs.getString(1));
				dto.setBirth(rs.getString(2));
				dto.setPhone(rs.getString(3));
				dto.setEmail(rs.getString(4));
				dto.setGender(rs.getString(5));
				dto.setImage(rs.getString(6));
				dto.setMemo(rs.getString(7));

				dtoList.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}

		if (dtoList.size() != 0) {
			dtoArr = new DTO[dtoList.size()];
			dtoList.toArray(dtoArr);
		}
		return dtoArr;

	}

	public void insert(DTO d) {

		try {
			pstmt = conn.prepareStatement(INSERT);
			pstmt.setString(1, d.getName());
			pstmt.setString(2, d.getBirth());
			pstmt.setString(3, d.getPhone());
			pstmt.setString(4, d.getEmail());
			pstmt.setString(5, d.getGender());
			pstmt.setString(6, d.getImage());
			pstmt.setString(7, d.getMemo());

			if (pstmt.executeUpdate() > 0) {
				System.out.println("�Է��� �Ϸ�Ǿ����ϴ�.");
			} else {
				System.out.println("�Է��� �����Ͽ����ϴ�.");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JdbcUtil.close(pstmt);// ��ĳ����
		}
	}

	public void update(DTO d, DTO d2) {
		try {
			pstmt = conn.prepareStatement(UPDATE);
			pstmt.setString(1, d.getName());
			pstmt.setString(2, d.getBirth());
			pstmt.setString(3, d.getPhone());
			pstmt.setString(4, d.getEmail());
			pstmt.setString(5, d.getGender());
			pstmt.setString(6, d.getImage());
			pstmt.setString(7, d.getMemo());
			pstmt.setString(8, d2.getPhone());

			if (pstmt.executeUpdate() > 0) {
				System.out.println("������ �Ϸ�Ǿ����ϴ�.");
			} else {
				System.out.println("������ �����Ͽ����ϴ�.");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JdbcUtil.close(pstmt);
		}
	}

	public DTO selectOne(DTO d) {

		DTO dto = null;

		try {
			pstmt = conn.prepareStatement(SELECTONE);
			pstmt.setString(1, d.getPhone());
			rs = pstmt.executeQuery();

			while (rs.next()) {
				dto = new DTO();
				dto.setName(rs.getString(1));
				dto.setBirth(rs.getString(2));
				dto.setPhone(rs.getString(3));
				dto.setEmail(rs.getString(4));
				dto.setGender(rs.getString(5));
				dto.setImage(rs.getString(6));
				dto.setMemo(rs.getString(7));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}

		return dto;
	}

	public DTO[] SelectAllExcludeOne(DTO d) {

		DTO[] dtoArr = null;
		ArrayList<DTO> dtoList = new ArrayList<>();

		try {
			pstmt = conn.prepareStatement(SELECTALLEXCLUDEONE);
			pstmt.setString(1, d.getPhone());
			rs = pstmt.executeQuery();

			while (rs.next()) {
				DTO dto = new DTO();
				dto.setName(rs.getString(1));
				dto.setBirth(rs.getString(2));
				dto.setPhone(rs.getString(3));
				dto.setEmail(rs.getString(4));
				dto.setGender(rs.getString(5));
				dto.setImage(rs.getString(6));
				dto.setMemo(rs.getString(7));

				dtoList.add(dto);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JdbcUtil.close(rs);
			JdbcUtil.close(pstmt);
		}

		if (dtoList.size() != 0) {
			dtoArr = new DTO[dtoList.size()];
			dtoList.toArray(dtoArr);
		}
		return dtoArr;
	}

	public void delete(DTO d) {
		try {
			pstmt = conn.prepareStatement(DELETE);
			pstmt.setString(1, d.getPhone());

			if (pstmt.executeUpdate() > 0) {
				System.out.println("������ �Ϸ�Ǿ����ϴ�.");
			} else {
				System.out.println("������ �����Ͽ����ϴ�.");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			JdbcUtil.close(pstmt);
		}
	}
}
