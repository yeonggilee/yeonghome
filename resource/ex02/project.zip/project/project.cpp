#include<stdio.h>
#include "GL/glut.h"
#include "math.h"
#include "Camera.h"

float r = 0.3;

float h = 0.25;
float b = 0.001f;

GLUquadricObj* cyl;

Camera cam;

float t = 0;
float p[3] = { 0, 2, 0 };
float v[3] = { 0.5, 0, 0 };
float a[3] = { 0, -5, 0 };
int check = 0;
int view = 1;

GLfloat MyVertices[8][3] = {
	{ 0, 1, 0 },
{ 0, 1, 1 },
{ 1,1,1 },
{ 1,1, 0 },
{ 0, 0, 0 },
{ 0, 0, 1 },
{ 1,0,1 },
{ 1, 0, 0 }
};
GLfloat MyColors[8][3] = {
	{ 1.0, 0.0, 1.0 },{ 1.0, 0.0, 1.0 },{ 1.0, 0.0, 1.0 },{ 0.0, 0.0, 1.0 },
{ 0.0, 0.0, 1.0 },{ 1.0, 0.0, 1.0 },{ 1.0, 1.0, 1.0 },{ 0.0, 1.0, 1.0 }
};
/*
GLubyte MyVertexList[24] = {
0, 3, 2, 1,
2, 3, 7, 6,
0, 4, 7, 3,
1, 2, 6, 5,
4, 5, 6, 7,
0, 1, 5, 4
};
*/
//3, 7, 6/ 4, 3, 6/ 7, 4, 6/ 3, 4, 7 (���ü, �Ѹ� �������� �ݽð����)
GLubyte MyVertexList[12] = {
	3, 7, 6,
	4, 3, 6,
	7, 4, 6,
	3, 4, 7
};
unsigned char* readBMP(const char* filename, int *pWidth, int *pHeight)
{
	int i;
	FILE* f = fopen(filename, "rb");
	unsigned char info[54];
	fread(info, sizeof(unsigned char), 54, f); // read the 54-byte header

											   // extract image height and width from header
	*pWidth = *(int*)&info[18];
	*pHeight = *(int*)&info[22];

	int size = 3 * *pWidth * *pHeight;
	unsigned char* data = new unsigned char[size]; // allocate 3 bytes per pixel
	fread(data, sizeof(unsigned char), size, f); // read the rest of the data at once
	fclose(f);

	return data;
}

void MyInit() {
	int width = 0, height = 0;
	GLvoid *lpImage = readBMP("ocean.bmp", &width, &height);//4�� ��� �ȼ��� �׸��ǿ��� �ѹ��� ��ȯ..
	glTexImage2D(GL_TEXTURE_2D, 0, 3, width, height, 0, GL_BGR_EXT,
		GL_UNSIGNED_BYTE, lpImage);

	// 8. �ؽ��� �Ӹ� ���� (+ 7. �� ������ GL_LINEAR_MIPMAP_LINEAR �� ����)
	gluBuild2DMipmaps(GL_TEXTURE_2D, 3, width, height, GL_BGR_EXT,
		GL_UNSIGNED_BYTE, lpImage);

	delete[]lpImage;

	// 6. �ؽ��� ��� �ܺ� ����
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP); // GL_REPEAT
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP); // GL_REPEAT

	// 7. �ؽ��� ���ø� ���� GL_LINEAR
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR_MIPMAP_LINEAR); // GL_LINEAR
	glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR); // GL_LINEAR

	// 3. ������ �ؽ��� ȥ�� GL_MODULATE. ���� glColor3f �Լ����� �������� ���� ���� �ǽ�
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE); // GL_MODULATE, GL_REPLACE

	// 1. �ؽ�ó ��� Ȱ��ȭ
	//glEnable(GL_TEXTURE_2D);

}

void InitLight() {

	GLfloat mat_diffuse[] = { 0.5, 0.4, 0.3, 1.0 };
	GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat mat_ambient[] = { 0.5, 0.4, 0.3, 1.0 };
	GLfloat mat_shininess[] = { 50.0 };
	GLfloat light_specular[] = { 1.0, 1.0, 1.0, 1.0 };
	GLfloat light_diffuse[] = { 0.8, 0.8, 0.8, 1.0 };
	GLfloat light_ambient[] = { 0.3, 0.3, 0.3, 1.0 };
	GLfloat light_position[] = { -3, 2, 3.0, 0.0 };

	glShadeModel(GL_SMOOTH);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	glLightfv(GL_LIGHT0, GL_POSITION, light_position);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialfv(GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_AMBIENT, mat_ambient);
	glMaterialfv(GL_FRONT, GL_SHININESS, mat_shininess);
}

void MyKeyboard(unsigned char KeyPressed, int X, int Y) {
	switch (KeyPressed) {
	case 'w':   cam.pitch(-0.5);  break;
	case 's':   cam.pitch(+0.5);  break;
	case 'a':   cam.yaw(-0.5);  break;
	case 'd':   cam.yaw(+0.5);  break;
	case 'q':   cam.roll(-0.5);  break;
	case 'e':   cam.roll(+0.5);  break;
	case 'i':  if (view == 1) cam.slide(0, 0.1, 0);  break;//1��Ī �ÿ� ī�޶� �̵� �Ұ�
	case 'k':  if (view == 1) cam.slide(0, -0.1, 0);  break;
	case 'j':  if (view == 1) cam.slide(-0.1, 0, 0);  break;
	case 'l':  if (view == 1) cam.slide(0.1, 0, 0);  break;
	case '[':  if (view == 1) cam.slide(0, 0, 0.1);  break;
	case ']':  if (view == 1) cam.slide(0, 0, -0.1);  break;
	case 'c':  if (view == 1) { view = 0; cam.setDefaultCamera(); }
			   else { view = 1; cam.set(0, 3, 4, 0, 0, 0, 0, 1, 0);
			   }
			   break;
	}

	glutPostRedisplay();

}

void MyIdle()
{
	t = t + 1;

	t = t + 1.0f;
	if (h <= 0.25) b = +0.0001f;
	if (h >= 0.75) b = -0.0001f;
	h = h + b;
	float time = 0.001;
	if (p[0] > 2.05) check = 1;

	if (check == 1) {
		v[0] = v[0] + a[0] * time;
		p[0] = p[0] + v[0] * time;
	}
	else {
		for (int i = 0; i < 3; i++)
			v[i] = v[i] + a[i] * time;
		for (int i = 0; i < 3; i++)
			p[i] = p[i] + v[i] * time;//�ٽ���ǥ

		if (p[1] < r) {
			v[1] = fabs(v[1]);
			p[1] = r;
		}
	}

	glutPostRedisplay();
}

void MyDisplay() {
	float mat_diffuse1[4] = { 0.5,0.4,0.3,1 };
	float mat_diffuse2[4] = { 0.5,0.9,0.3,1 };
	float mat_diffuse3[4] = { 0.5,0.0,0.5,1 };

	//glLoadIdentity();
	//gluLookAt(2, 1, 8, 0, 0, 0, 0, 1, 0);
	cyl = gluNewQuadric();
	gluQuadricDrawStyle(cyl, GLU_FILL);

	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glMatrixMode(GL_MODELVIEW);

	//���� �ʿ��� �κ�/////////////////////////////////////////////////////////////
	glDisable(GL_TEXTURE_2D);
	glEnable(GL_LIGHTING);

	glPushMatrix();
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse1);//����1
	if (check == 1) glTranslated(p[0], 0.1, 0);//���� ������ ���� �̵�
	else glTranslatef(2, 0.1, 0);//�׳� �ִٰ�
								 //glColor3f(1.0, 0.0, 0.0);
	glRotatef(90, 1, 0, 0);//������
	glutSolidTorus(0.2, 0.4, 20, 20);//�䷯��
	glPopMatrix();

	glPushMatrix();
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse2);//����2
	glTranslatef(p[0], p[1], p[2]);//���������� Ƣ�鼭 �̵�
								   //glColor3f(1.0, 0.0, 0.0);
	glutSolidSphere(r, 10, 10);//��
	glPopMatrix();

	// 1. ����
	glPushMatrix();

	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse3);
	glRotatef(0, 0, 1, 0);
	glTranslatef(0, 0.5, t * 0.0001); //��� ��ü �����̱�

	glPushMatrix();
	glRotatef(-90, 1, 0, 0);
	gluCylinder(cyl, 0.1, 0.1, 0.5, 20, 1); //0.1, 0.1, 0.5 ����
	glPopMatrix();
	// �� 
	glPushMatrix();
	glTranslated(0, 0.5, 0);
	glRotatef(-90, 1, 0, 0);
	gluCylinder(cyl, 0.03, 0.03, 0.06, 20, 1);
	glPopMatrix();
	//�Ӹ�
	glPushMatrix();
	glTranslated(0, 0.65, 0);
	glutSolidSphere(0.12, 20, 20); //0.1, 0.1, 0.5 ����
	glPopMatrix();

	// 2. �� ��
	glPushMatrix();
	glTranslatef(0.15, 0.5, 0);
	glutSolidSphere(0.05, 20, 20);
	glRotatef(90 + 20 * sin(t*0.001), 1, 0, 0);
	gluCylinder(cyl, 0.05, 0.05, 0.2, 20, 1);
	//�Ȳ�ġ
	glTranslatef(0, 0.0, 0.2);
	glutSolidSphere(0.05, 20, 20);
	glRotatef(10 * sin(t * 0.001) - 10, 1, 0, 0);
	gluCylinder(cyl, 0.05, 0.05, 0.2, 10, 1);
	//��
	glTranslatef(0, 0.0, 0.2);
	glutSolidSphere(0.05, 20, 20);
	glPopMatrix();

	//������
	glPushMatrix();
	glTranslatef(-0.15, 0.5, 0);
	glutSolidSphere(0.05, 20, 20);
	glRotatef(90 + 20 * sin(-t * 0.001), 1, 0, 0);
	gluCylinder(cyl, 0.05, 0.05, 0.2, 20, 1);
	//�Ȳ�ġ
	glTranslatef(0, 0.0, 0.2);
	glutSolidSphere(0.05, 20, 20);
	glRotatef(10 * sin(-t * 0.001) - 10, 1, 0, 0);
	gluCylinder(cyl, 0.05, 0.05, 0.2, 10, 1);
	//��
	glTranslatef(0, 0.0, 0.2);
	glutSolidSphere(0.05, 22, 22);
	glPopMatrix();

	//���ʴٸ� 
	glPushMatrix();
	glTranslatef(0.1, 0, 0);
	glutSolidSphere(0.05, 20, 20);
	glRotatef(70 + 20 * sin(-t * 0.001), 1, 0, 0);
	gluCylinder(cyl, 0.05, 0.05, 0.2, 20, 1);
	//���Ƹ�
	glTranslatef(0, 0.0, 0.2);
	glutSolidSphere(0.05, 20, 20);
	glRotatef(25 + 10 * sin(-t * 0.001), 1, 0, 0);
	gluCylinder(cyl, 0.05, 0.05, 0.2, 10, 1);
	//��
	glTranslatef(0, -0.04, 0.2);
	glRotatef(-90, 1, 0, 0);
	gluCylinder(cyl, 0.035, 0.03, 0.19, 60, 1);
	glPopMatrix();

	//�����ٸ�
	glPushMatrix();
	glTranslatef(-0.1, 0, 0);
	glutSolidSphere(0.05, 20, 20);
	glRotatef(70 + 20 * sin(t*0.001), 1, 0, 0);
	gluCylinder(cyl, 0.05, 0.05, 0.2, 20, 1);
	//���Ƹ�
	glTranslatef(0, 0.0, 0.2);
	glutSolidSphere(0.05, 20, 20);
	glRotatef(20 + 10 * sin(-t * 0.001), 1, 0, 0);
	gluCylinder(cyl, 0.05, 0.05, 0.2, 10, 1);
	//��
	glTranslatef(0, -0.04, 0.2);
	glRotatef(-90, 1, 0, 0);
	gluCylinder(cyl, 0.035, 0.03, 0.19, 60, 1);
	glPopMatrix();

	glPopMatrix();

	//���� �ʿ� ���� �κ�///////////////////////////////////////////////////////
	glEnable(GL_TEXTURE_2D);
	glDisable(GL_LIGHTING);

	//glClear(GL_COLOR_BUFFER_BIT);
	// 9. index buffer Ȱ��.
	if (false) {
		float MyVertices[4][3] = { { -1.0, -1.0, 0.0 },
		{ -1.0, 1.0, 0.0 },
		{ 1.0, -1.0, 0.0 },
		{ 1.0, 1.0, 0.0 } };
		float MyTexCoords[4][2] = { { 0,0 },{ 0,1 },{ 1,0 },{ 1,1 } };

		glEnableClientState(GL_VERTEX_ARRAY);
		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		glVertexPointer(3, GL_FLOAT, 0, MyVertices);
		glTexCoordPointer(2, GL_FLOAT, 0, MyTexCoords);

		GLubyte MyIndex[4] = { 0,1,2,3 };
		glDrawElements(GL_TRIANGLE_STRIP, 4, GL_UNSIGNED_BYTE, MyIndex); // 3, GL_UNSIGNED_BYTE, MyIndex+1
		glutSwapBuffers();
		return;
	}

	// 4. �ؽ��� ��ǥ ���� 0~1 ����
	// 5. �ؽ��� ��ǥ ���� 1���� ū �� (3,4,5)
	glBegin(GL_TRIANGLE_STRIP);//�ٴںκ�
	glTexCoord2f(0.0, 0.0); glVertex3f(-2.5, 0, -2.5);
	glTexCoord2f(0.0, 1.0); glVertex3f(-2.5, 0, 2.5);
	glTexCoord2f(1.0, 0.0); glVertex3f(8.5, 0, -2.5);
	glTexCoord2f(1.0, 1.0); glVertex3f(8.5, 0, 2.5);
	glEnd();
	//

	//�ڽ�
	glPushMatrix();

	glEnableClientState(GL_COLOR_ARRAY);
	glEnableClientState(GL_VERTEX_ARRAY);//Ȱ��ȭ
	glColorPointer(3, GL_FLOAT, 0, MyColors);
	glVertexPointer(3, GL_FLOAT, 0, MyVertices);//������ ���������� ���� (3���� ���, GL_FLOAT������, �������, �迭)�� �о��

	
	glTranslatef(-2.5, 0.0, -2.0);
	glScalef(2.0, 2.0, 2.0);
	//glRotatef(45.0*t*0.001, 1.0, 1.0, 1.0);//ȸ��(����, ������, ������, ������)
	//for (GLint i = 0; i < 6; i++)
	//	glDrawElements(GL_POLYGON, 4, GL_UNSIGNED_BYTE, &MyVertexList[4 * i]);//��� �׸���(�ٰ���, 4����, �迭Ÿ��(GLubyte), �迭�����ּ�)
	for (GLint i = 0; i < 4; i++)
		glDrawElements(GL_POLYGON, 3, GL_UNSIGNED_BYTE, &MyVertexList[3 * i]);
	glPopMatrix();
	//


	glutSwapBuffers();

}

int main(int argc, char** argv) {

	printf("========���۹�=======\n");
	printf("w: ƿ�� ��\n");
	printf("s: ƿ�� �ٿ�\n");
	printf("a: �д� ����Ʈ\n");
	printf("d: �д� ����Ʈ\n");
	printf("q: �Ѹ� ����Ʈ\n");
	printf("e: �Ѹ� ����Ʈ\n");
	printf("\n");
	printf("i: ���� �̵�\n");
	printf("k: �Ʒ��� �̵�\n");
	printf("j: �������� �̵�\n");
	printf("l: ���������� �̵�\n");
	printf("[: ���������\n");
	printf("]: �־�����\n");
	printf("\n");
	printf("c: ���� ��ȯ\n");
	printf("=====================\n");

	glutInit(&argc, argv);               //GLUT ������ �Լ�
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 800);
	glutInitWindowPosition(0, 0);
	glutCreateWindow("OpenGL Sample Drawing");

	glEnable(GL_DEPTH_TEST);
	glClearColor(1.0, 1.0, 1.0, 1.0);   //GL ���º��� ����
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(100, 1, 0.1, 100);

	cam.set(0, 3, 4, 0, 0, 0, 0, 1, 0);//ī�޶� ����
	InitLight();//����
	MyInit();//�ؽ���
	glutDisplayFunc(MyDisplay);
	glutIdleFunc(MyIdle);
	glutKeyboardFunc(MyKeyboard);//Ű���� ����
	glutMainLoop();

	return 0;

}