package com.cafe24.sosang.dto;

public class Quarter_FloatingPopDTO {
	private int q1_y2017;
	private int q2_y2017;
	private int q3_y2017;
	private int q4_y2017;
	private int q1_y2018;
	private int q2_y2018;
	private int q3_y2018;
	private int q4_y2018;
	private int q1_y2019;
	private int q2_y2019;

	public int getQ1_y2017() {
		return q1_y2017;
	}

	public void setQ1_y2017(int q1_y2017) {
		this.q1_y2017 = q1_y2017;
	}

	public int getQ2_y2017() {
		return q2_y2017;
	}

	public void setQ2_y2017(int q2_y2017) {
		this.q2_y2017 = q2_y2017;
	}

	public int getQ3_y2017() {
		return q3_y2017;
	}

	public void setQ3_y2017(int q3_y2017) {
		this.q3_y2017 = q3_y2017;
	}

	public int getQ4_y2017() {
		return q4_y2017;
	}

	public void setQ4_y2017(int q4_y2017) {
		this.q4_y2017 = q4_y2017;
	}

	public int getQ1_y2018() {
		return q1_y2018;
	}

	public void setQ1_y2018(int q1_y2018) {
		this.q1_y2018 = q1_y2018;
	}

	public int getQ2_y2018() {
		return q2_y2018;
	}

	public void setQ2_y2018(int q2_y2018) {
		this.q2_y2018 = q2_y2018;
	}

	public int getQ3_y2018() {
		return q3_y2018;
	}

	public void setQ3_y2018(int q3_y2018) {
		this.q3_y2018 = q3_y2018;
	}

	public int getQ4_y2018() {
		return q4_y2018;
	}

	public void setQ4_y2018(int q4_y2018) {
		this.q4_y2018 = q4_y2018;
	}

	public int getQ1_y2019() {
		return q1_y2019;
	}

	public void setQ1_y2019(int q1_y2019) {
		this.q1_y2019 = q1_y2019;
	}

	public int getQ2_y2019() {
		return q2_y2019;
	}

	public void setQ2_y2019(int q2_y2019) {
		this.q2_y2019 = q2_y2019;
	}

	@Override
	public String toString() {
		return "[q1_y2017=" + q1_y2017 + ", q2_y2017=" + q2_y2017 + ", q3_y2017=" + q3_y2017 + ", q4_y2017=" + q4_y2017
				+ ", q1_y2018=" + q1_y2018 + ", q2_y2018=" + q2_y2018 + ", q3_y2018=" + q3_y2018 + ", q4_y2018="
				+ q4_y2018 + ", q1_y2019=" + q1_y2019 + ", q2_y2019=" + q2_y2019 + "]";
	}

}
