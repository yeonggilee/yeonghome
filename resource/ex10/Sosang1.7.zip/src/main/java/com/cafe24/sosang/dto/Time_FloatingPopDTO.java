package com.cafe24.sosang.dto;

public class Time_FloatingPopDTO {
	private int total;
	private int total_time1;
	private int total_time2;
	private int total_time3;
	private int total_time4;
	private int total_time5;
	private int total_time6;
	
	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public int getTotal_time1() {
		return total_time1;
	}

	public void setTotal_time1(int total_time1) {
		this.total_time1 = total_time1;
	}

	public int getTotal_time2() {
		return total_time2;
	}

	public void setTotal_time2(int total_time2) {
		this.total_time2 = total_time2;
	}

	public int getTotal_time3() {
		return total_time3;
	}

	public void setTotal_time3(int total_time3) {
		this.total_time3 = total_time3;
	}

	public int getTotal_time4() {
		return total_time4;
	}

	public void setTotal_time4(int total_time4) {
		this.total_time4 = total_time4;
	}

	public int getTotal_time5() {
		return total_time5;
	}

	public void setTotal_time5(int total_time5) {
		this.total_time5 = total_time5;
	}

	public int getTotal_time6() {
		return total_time6;
	}

	public void setTotal_time6(int total_time6) {
		this.total_time6 = total_time6;
	}

	@Override
	public String toString() {
		return "[total=" + total + ", total_time1=" + total_time1 + ", total_time2=" + total_time2
				+ ", total_time3=" + total_time3 + ", total_time4=" + total_time4 + ", total_time5=" + total_time5
				+ ", total_time6=" + total_time6 + "]";
	}

}
