package com.cafe24.sosang.dto;

public class ApartmentDTO {
	private String apart_Price_avg;
	private String apart_avg;
	private String avg_area;
	private String avg_Price;
	private String apartment_Avg;
	private String non_apartment_Avg;
	private String family_avg;
	private String family_total;
	private String apartment_total;
	private String non_apartment_total;
	private String apart_family;
	private String area_66_under_households;
	private String area_66_households;
	private String area_99_households;
	private String area_132_households;
	private String area_165_households;
	private String area_66_under_Avg;
	private String area_66_Avg;
	private String area_99_Avg;
	private String area_132_Avg;
	private String area_165_Avg;
	private String price_1milion_under;
	private String price_1milion;
	private String price_2milion;
	private String price_3milion;
	private String price_4milion;
	private String price_5milion;
	private String price_6milion;
	private String price_1milion_under_Avg;
	private String price_1milion_Avg;
	private String price_2milion_Avg;
	private String price_3milion_Avg;
	private String price_4milion_Avg;
	private String price_5milion_Avg;
	private String price_6milion_Avg;
	public String getApartment_Avg() {
		return apartment_Avg;
	}
	public String getNon_apartment_Avg() {
		return non_apartment_Avg;
	}
	public String getFamily_avg() {
		return family_avg;
	}
	public String getFamily_total() {
		return family_total;
	}
	public String getApartment_total() {
		return apartment_total;
	}
	public String getNon_apartment_total() {
		return non_apartment_total;
	}
	public String getApart_family() {
		return apart_family;
	}
	public String getArea_66_under_households() {
		return area_66_under_households;
	}
	public String getArea_66_households() {
		return area_66_households;
	}
	public String getArea_99_households() {
		return area_99_households;
	}
	public String getArea_132_households() {
		return area_132_households;
	}
	public String getArea_165_households() {
		return area_165_households;
	}
	public String getArea_66_under_Avg() {
		return area_66_under_Avg;
	}
	public String getArea_66_Avg() {
		return area_66_Avg;
	}
	public String getArea_99_Avg() {
		return area_99_Avg;
	}
	public String getArea_132_Avg() {
		return area_132_Avg;
	}
	public String getArea_165_Avg() {
		return area_165_Avg;
	}
	

	public String getPrice_1milion() {
		return price_1milion;
	}
	public String getPrice_2milion() {
		return price_2milion;
	}
	public String getPrice_3milion() {
		return price_3milion;
	}
	public String getPrice_4milion() {
		return price_4milion;
	}
	public String getPrice_5milion() {
		return price_5milion;
	}
	public String getPrice_6milion() {
		return price_6milion;
	}
	public String getPrice_1milion_under_Avg() {
		return price_1milion_under_Avg;
	}
	public String getPrice_1milion_Avg() {
		return price_1milion_Avg;
	}
	public String getPrice_2milion_Avg() {
		return price_2milion_Avg;
	}
	public String getPrice_3milion_Avg() {
		return price_3milion_Avg;
	}
	public String getPrice_4milion_Avg() {
		return price_4milion_Avg;
	}
	public String getPrice_5milion_Avg() {
		return price_5milion_Avg;
	}
	public String getPrice_6milion_Avg() {
		return price_6milion_Avg;
	}
	public void setApartment_Avg(String apartment_Avg) {
		this.apartment_Avg = apartment_Avg;
	}
	public void setNon_apartment_Avg(String non_apartment_Avg) {
		this.non_apartment_Avg = non_apartment_Avg;
	}
	public void setFamily_avg(String family_avg) {
		this.family_avg = family_avg;
	}
	public void setFamily_total(String family_total) {
		this.family_total = family_total;
	}
	public void setApartment_total(String apartment_total) {
		this.apartment_total = apartment_total;
	}
	public void setNon_apartment_total(String non_apartment_total) {
		this.non_apartment_total = non_apartment_total;
	}
	public void setApart_family(String apart_family) {
		this.apart_family = apart_family;
	}
	public void setArea_66_under_households(String area_66_under_households) {
		this.area_66_under_households = area_66_under_households;
	}
	public void setArea_66_households(String area_66_households) {
		this.area_66_households = area_66_households;
	}
	public void setArea_99_households(String area_99_households) {
		this.area_99_households = area_99_households;
	}
	public void setArea_132_households(String area_132_households) {
		this.area_132_households = area_132_households;
	}
	public void setArea_165_households(String area_165_households) {
		this.area_165_households = area_165_households;
	}
	public void setArea_66_under_Avg(String area_66_under_Avg) {
		this.area_66_under_Avg = area_66_under_Avg;
	}
	public void setArea_66_Avg(String area_66_Avg) {
		this.area_66_Avg = area_66_Avg;
	}
	public void setArea_99_Avg(String area_99_Avg) {
		this.area_99_Avg = area_99_Avg;
	}
	public void setArea_132_Avg(String area_132_Avg) {
		this.area_132_Avg = area_132_Avg;
	}
	public void setArea_165_Avg(String area_165_Avg) {
		this.area_165_Avg = area_165_Avg;
	}
	public void setPrice_1milion(String price_1milion) {
		this.price_1milion = price_1milion;
	}
	public void setPrice_2milion(String price_2milion) {
		this.price_2milion = price_2milion;
	}
	public void setPrice_3milion(String price_3milion) {
		this.price_3milion = price_3milion;
	}
	public void setPrice_4milion(String price_4milion) {
		this.price_4milion = price_4milion;
	}
	public void setPrice_5milion(String price_5milion) {
		this.price_5milion = price_5milion;
	}
	public void setPrice_6milion(String price_6milion) {
		this.price_6milion = price_6milion;
	}
	public void setPrice_1milion_under_Avg(String price_1milion_under_Avg) {
		this.price_1milion_under_Avg = price_1milion_under_Avg;
	}
	public void setPrice_1milion_Avg(String price_1milion_Avg) {
		this.price_1milion_Avg = price_1milion_Avg;
	}
	public void setPrice_2milion_Avg(String price_2milion_Avg) {
		this.price_2milion_Avg = price_2milion_Avg;
	}
	public void setPrice_3milion_Avg(String price_3milion_Avg) {
		this.price_3milion_Avg = price_3milion_Avg;
	}
	public void setPrice_4milion_Avg(String price_4milion_Avg) {
		this.price_4milion_Avg = price_4milion_Avg;
	}
	public void setPrice_5milion_Avg(String price_5milion_Avg) {
		this.price_5milion_Avg = price_5milion_Avg;
	}
	public void setPrice_6milion_Avg(String price_6milion_Avg) {
		this.price_6milion_Avg = price_6milion_Avg;
	}
	
	public String getAvg_area() {
		return avg_area;
	}
	public String getAvg_Price() {
		return avg_Price;
	}
	public void setArea_avg(String avg_area) {
		this.avg_area = avg_area;
	}
	public void setAvg_Price(String avg_Price) {
		this.avg_Price = avg_Price;
	}
	
	public String getApart_avg() {
		return apart_avg;
	}
	public void setApart_avg(String apart_avg) {
		this.apart_avg = apart_avg;
	}
	
	public String getApart_Price_avg() {
		return apart_Price_avg;
	}
	public void setApart_Price_avg(String apart_Price_avg) {
		this.apart_Price_avg = apart_Price_avg;
	}
	public String getPrice_1milion_under() {
		return price_1milion_under;
	}
	public void setPrice_1milion_under(String price_1milion_under) {
		this.price_1milion_under = price_1milion_under;
	}
	@Override
	public String toString() {
		return "ApartmentDTO [apart_Price_avg=" + apart_Price_avg + ", apart_avg=" + apart_avg + ", avg_area="
				+ avg_area + ", avg_Price=" + avg_Price + ", apartment_Avg=" + apartment_Avg + ", non_apartment_Avg="
				+ non_apartment_Avg + ", family_avg=" + family_avg + ", family_total=" + family_total
				+ ", apartment_total=" + apartment_total + ", non_apartment_total=" + non_apartment_total
				+ ", apart_family=" + apart_family + ", area_66_under_households=" + area_66_under_households
				+ ", area_66_households=" + area_66_households + ", area_99_households=" + area_99_households
				+ ", area_132_households=" + area_132_households + ", area_165_households=" + area_165_households
				+ ", area_66_under_Avg=" + area_66_under_Avg + ", area_66_Avg=" + area_66_Avg + ", area_99_Avg="
				+ area_99_Avg + ", area_132_Avg=" + area_132_Avg + ", area_165_Avg=" + area_165_Avg
				+ ", price_1milion_under=" + price_1milion_under + ", price_1milion=" + price_1milion
				+ ", price_2milion=" + price_2milion + ", price_3milion=" + price_3milion + ", price_4milion="
				+ price_4milion + ", price_5milion=" + price_5milion + ", price_6milion=" + price_6milion
				+ ", price_1milion_under_Avg=" + price_1milion_under_Avg + ", price_1milion_Avg=" + price_1milion_Avg
				+ ", price_2milion_Avg=" + price_2milion_Avg + ", price_3milion_Avg=" + price_3milion_Avg
				+ ", price_4milion_Avg=" + price_4milion_Avg + ", price_5milion_Avg=" + price_5milion_Avg
				+ ", price_6milion_Avg=" + price_6milion_Avg + "]";
	}


	
	
	
}
